package projetoNavio;

import projetoNavio.Controle;

/**
 * @author Jessica Maria
 */
public class Navio {
    private int cdNavio;
    private String nomeNavio;
    private String nomeCapitao;
    private String nomeDestino;
    private String dtSaida;
    private String dtRetorno;    
    private Controle control;

    public Navio() {
    }

    public Navio(int cdNavio, String nomeNavio, String nomeCapitao, String nomeDestino, String dtSaida, String dtRetorno) {
        this.cdNavio=cdNavio;
        this.nomeNavio=nomeNavio;
        this.nomeCapitao=nomeCapitao;
        this.nomeDestino=nomeDestino;
        this.dtSaida=dtSaida;
        this.dtRetorno=dtRetorno;
    }

    /**
     * @return the cdNavio
     */
    public int getCdNavio() {
        return cdNavio;
    }

    /**
     * @param cdNavio the cdNavio to set
     */
    public void setCdNavio(int cdNavio) {
        this.cdNavio = cdNavio;
    }

    /**
     * @return the nomeNavio
     */
    public String getNomeNavio() {
        return nomeNavio;
    }

    /**
     * @param nomeNavio the nomeNavio to set
     */
    public void setNomeNavio(String nomeNavio) {
        this.nomeNavio = nomeNavio;
    }

    /**
     * @return the nomeCapitao
     */
    public String getNomeCapitao() {
        return nomeCapitao;
    }

    /**
     * @param nomeCapitao the nomeCapitao to set
     */
    public void setNomeCapitao(String nomeCapitao) {
        this.nomeCapitao = nomeCapitao;
    }

    /**
     * @return the nomeDestino
     */
    public String getNomeDestino() {
        return nomeDestino;
    }

    /**
     * @param nomeDestino the nomeDestino to set
     */
    public void setNomeDestino(String nomeDestino) {
        this.nomeDestino = nomeDestino;
    }

    /**
     * @return the dtSaida
     */
    public String getDtSaida() {
        return dtSaida;
    }

    /**
     * @param dtSaida the dtSaida to set
     */
    public void setDtSaida(String dtSaida) {
        this.dtSaida = dtSaida;
    }

    /**
     * @return the dtRetorno
     */
    public String getDtRetorno() {
        return dtRetorno;
    }

    /**
     * @param dtRetorno the dtRetorno to set
     */
    public void setDtRetorno(String dtRetorno) {
        this.dtRetorno = dtRetorno;
    }

    /**
     * @return the control
     */
    public Controle getControl() {
        return control;
    }

    /**
     * @param control the control to set
     */
    public void setControl(Controle control) {
        this.control = control;
    }

    
}
