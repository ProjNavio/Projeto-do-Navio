package projetoNavio;

import java.util.ArrayList;

/**
 * @author Jessica Maria
 */
public class Controle {
    private int Codigo;
    private String Nome;
    ArrayList<Navio> ListaNavio;

    public Controle() {
        ListaNavio = new ArrayList();
    }

    public Controle(int Codigo, String Nome) {
        this.Codigo = Codigo;
        this.Nome = Nome;
        ListaNavio = new ArrayList();
    }

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public ArrayList<Navio> getListaNavio() {
        return ListaNavio;
    }

    public void setListaNavio(ArrayList<Navio> ListaNavio) {
        this.ListaNavio = ListaNavio;
    }
    
    public void addNavio(Navio n){
        n.setControl(this);
        ListaNavio.add(n);
    }
}
